#include <bits/stdc++.h>
using namespace std;

#define int long long 
#define ftype double

const double EPS = 1e-9;

//make sure to define ftype as int / float / double as required
//It can be used as 2D as well

struct point {
    ftype x, y, z=0;
    point() {}
    point(ftype x, ftype y, ftype z=0): x(x), y(y), z(z) {}
    
    point& operator=( pair<ftype,ftype> P)
    {
     x=P.first;
     y=P.second;
        return *this;
    }

    bool operator==(const point &t)
    {
      return (x==t.x && y==t.y && z==t.z);  
    }
    
    point& operator+=(const point &t) {
        x += t.x;
        y += t.y;
        z += t.z;
        return *this;
    }
    
    
    point& operator-=(const point &t) {
        x -= t.x;
        y -= t.y;
        z -= t.z;
        return *this;
    }
    
     point& operator/=(const point &t) {
        
        return *this;
    }
    
    point& operator*=(ftype t) {
        x *= t;
        y *= t;
        z *= t;
        return *this;
    }
    point& operator/=(ftype t) {
        x /= t;
        y /= t;
        z /= t;
        return *this;
    }
    
    point operator+(const point &t) const {
        return point(*this) += t;
    }
    point operator-(const point &t) const {
        return point(*this) -= t;
    }
    point operator*(ftype t) const {
        return point(*this) *= t;
    }
  
    point operator/(ftype t) const {
        return point(*this) /= t;
    }
    
    point operator/(const point &t) const {
        return point(*this) /= t;
    }
    
    
    bool operator<(const point& p) const
    {
        return x < p.x - EPS || (abs(x - p.x) < EPS && y < p.y - EPS);
    }
    
};

ftype dot(point a, point b) {
    return a.x * b.x + a.y * b.y + a.z * b.z;
}

ftype norm(point a) {
    return dot(a, a);
}

double abs(point a) {
    return sqrt(norm(a));
}

double proj(point a, point b) {
    return dot(a, b) / abs(b);
}

double angle(point a, point b) {
    return acos(dot(a, b) / abs(a) / abs(b));
}


point cross(point a, point b) {
    return point(a.y * b.z - a.z * b.y,
                   a.z * b.x - a.x * b.z,
                   a.x * b.y - a.y * b.x);
}

//volume of parallelepiped
ftype triple(point a, point b, point c) {
    return dot(a, cross(b, c));
}

//only for 2D lines given in vector form
point intersect (point a1, point d1, point a2, point d2) {
    return a1 + d1*(cross(a2 - a1, d2).z/cross(d1, d2).z ) ;
}

//ax + by = c
struct line
{
 ftype a,b,c;
    
    line() {}
    
    //passing through p and q
    line(point p,point q)
    {
     a=p.y-q.y;
     b=q.x-p.x;
     c=(a*p.x)+(b*p.y);
        
    norm();
    }
    
    line(ftype a1,ftype b1,ftype c1)
    {
    a = a1;
    b = b1;
    c = c1;
        
        norm();
    }
    
    void norm()
    {
        double z = sqrt(a * a + b * b);
        if (abs(z) > EPS)
            a /= z, b /= z, c /= z;
        
        if(a<0 || (a==0 && b<0) ) 
            a=-a,b=-b,c=-c;
    }
    
    double distance(point p)
    {
      norm();
      return abs(a*p.x + b*p.y - c); 
    }
    
    void shift_origin(point p)
    {
     c = c - (p.x*a + p.y*b);       
    }
    
};

ftype give_x(line L,ftype y)
{
    if(L.a==0) { cerr << " error : parallel to  x axis\n"; return -1; }
 return (L.c-(L.b*y))/(L.a);   
}

ftype give_y(line L,ftype x)
{
        if(L.b==0) { cerr << " error : parallel to  y axis\n"; return -1; }
 return (L.c-(L.a*x))/(L.b);   
}

bool satisfy(line L,point p)
{
return (L.a*p.x + L.b*p.y == L.c);
}

double det(double a, double b, double c, double d) {
    return a*d - b*c;
}

//for line in 2-D
bool intersect(line m, line n, point & res) {
    double zn = det(m.a, m.b, n.a, n.b);
    if (abs(zn) < EPS)
        return false;
    res.x = -det(m.c, m.b, n.c, n.b) / zn;
    res.y = -det(m.a, m.c, n.a, n.c) / zn;
    return true;
}

bool parallel(line m, line n) {
    return abs(det(m.a, m.b, n.a, n.b)) < EPS;
}

bool equivalent(line m, line n) {
    return abs(det(m.a, m.b, n.a, n.b)) < EPS
        && abs(det(m.a, m.c, n.a, n.c)) < EPS
        && abs(det(m.b, m.c, n.b, n.c)) < EPS;
}

double distance(line a,line b)
{
   a.norm();
   b.norm();
    
    if(parallel(a,b) ) return 0;
    else return abs(a.c-b.c);
}

//intersection of 2D line-segments , given endpoints of both segments
//All cases covered
inline bool betw(double l, double r, double x)
{
    return min(l, r) <= x + EPS && x <= max(l, r) + EPS;
}

inline bool seg_intersect_1d(double a, double b, double c, double d)
{
    if (a > b)
        swap(a, b);
    if (c > d)
        swap(c, d);
    return max(a, c) <= min(b, d) + EPS;
}

bool seg_intersect(point a, point b, point c, point d, point& left, point& right)
{
    if (!seg_intersect_1d(a.x, b.x, c.x, d.x) || !seg_intersect_1d(a.y, b.y, c.y, d.y))
        return false;
    
    line m(a, b);
    line n(c, d);
    
    double zn = det(m.a, m.b, n.a, n.b);
    
    if (abs(zn) < EPS) {
        if (abs(m.distance(c)) > EPS || abs(n.distance(a)) > EPS)
            return false;
        
        if (b < a)
            swap(a, b);
        if (d < c)
            swap(c, d);
        left = max(a, c);
        right = min(b, d);
        return true;
    } else {
    
        left.x = right.x = det(m.c, m.b, n.c, n.b) / zn;
        left.y = right.y = det(m.a, m.c, n.a, n.c) / zn;
        
        return betw(a.x, b.x, left.x) && betw(a.y, b.y, left.y) &&
               betw(c.x, d.x, left.x) && betw(c.y, d.y, left.y);
    }
}

//Area of polygon
double area(const vector<point>& fig) {
    double res = 0;
    for (unsigned i = 0; i < fig.size(); i++) {
        point p = i ? fig[i - 1] : fig.back();
        point q = fig[i];
        res += (p.x - q.x) * (p.y + q.y);
    }
    return fabs(res) / 2;
}

//Helpful for Pick's theorem Area = (Integer points on Boundary)/2 + (Interger points inside) - 1
//Note : Assumed that p and q have interger coordinates and thus boundary is included 

int interger_points(point p,point q)
{
    // Check if line parallel to axes 
    if (p.x==q.x) 
        return abs(p.y - q.y) + 1; 
    if (p.y == q.y) 
        return abs(p.x-q.x) + 1; 
  
    return __gcd((int)abs(p.x-q.x),(int)abs(p.y-q.y))+1;    
}

//we can check for a point in polygon in O(n) using below function,
//if area of polygon = summation (abs(area of triangle (P(i),P(i+1),given point)))

//To check if point is inside a triangle
bool pointInTriangle(point a, point b, point c, point P)
{
    long long s1 = abs(cross2d(b-a,c-a));
    long long s2 = abs(cross2d(a-P,b-P)) + abs(cross2d(b-P,c-P)) + abs(cross2d(c-P,a-P));
    return s1 == s2;
}

//clockwise : right turn
bool cw(point a, point b, point c) {
    return a.x*(b.y-c.y)+b.x*(c.y-a.y)+c.x*(a.y-b.y) < 0;
}

//counter-clockwise : left turn
bool ccw(point a, point b, point c) {
    return a.x*(b.y-c.y)+b.x*(c.y-a.y)+c.x*(a.y-b.y) > 0;
}

//Andrew's Algorithm to find convex hull for the given set of points in O(nlogn)
void convex_hull(vector<point> & a)
{
    if(a.size()==1) return;
       
    //points are sorted according  to x coordinates ( tie broken by y)   
    //remove if already sorted
    sort(a.begin(),a.end());

    //remove duplicates - a corner case
    auto ip = unique(a.begin(),a.end());
    a.resize(distance(a.begin(),ip));

    point p1 = a[0],p2=a.back();   
    vector<point> up,down;

    int n = a.size();    

    up.push_back(p1),down.push_back(p1);   

    for(int i=1;i<n;i++)  
    {
        //upper hull
        if (i == a.size() - 1 || cw(p1, a[i], p2)) {
                while (up.size() >= 2 && !cw(up[up.size()-2], up[up.size()-1], a[i]))
                    up.pop_back();
           
                up.push_back(a[i]);
        }
      
        //lower hull 
        if (i == a.size() - 1 || ccw(p1, a[i], p2)) {
                while(down.size() >= 2 && !ccw(down[down.size()-2], down[down.size()-1], a[i]))
                    down.pop_back();
          
                down.push_back(a[i]);
            } 
    } 
   
    //Merging points of upper and lower hull into a  in clockwise fashion 
    a.clear();
    for (int i = 0; i < (int)up.size(); i++)
        a.push_back(up[i]);
    for (int i = down.size() - 2; i > 0; i--)
        a.push_back(down[i]); 
    
}