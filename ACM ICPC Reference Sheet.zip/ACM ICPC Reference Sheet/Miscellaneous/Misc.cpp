//Random Generator 

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

int getRand(int l, int r)
{
    uniform_int_distribution<int> uid(l, r);
    return uid(rng);
}

//Ordered set

#include <ext/pb_ds/assoc_container.hpp> 
#include <ext/pb_ds/tree_policy.hpp> 
using namespace __gnu_pbds; 

#define ordered_set tree<int, null_type,less<int>, rb_tree_tag,tree_order_statistics_node_update> 

//Mod power

int mod_pow(int a,int b,int M = MOD){
    if(a == 0) return 0;
    b %= (M - 1);  //M must be prime here
    
    int res = 1;
    
    while(b > 0){
        if(b&1) res=(res*a)%M;
        a=(a*a)%M;
        b>>=1;
    }
    
    return res;
}

//Iterate over floor(n/i) in O(root(n)).
for (int i = 1, la; i <= n; i = la + 1) {
	la = n / (n / i);
	//n / x yields the same value for i <= x <= la.
}

//Enumerating submasks of a mask
for (int s=m; ; s=(s-1)&m) {
 ... you can use s ...
 if (s==0)  break;
}

//Some useful functions  
Number of leading zeroes: builtin_clz(x)
Number of trailing zeroes : builtin_ctz(x)
Number of 1-bits: __builtin_popcount(x) 	

//Code Optimizations 
#pragma GCC optimize("O3")
#pragma GCC target("avx2")
#pragma GCC optimize("unroll-loops")

//catalan number
// (2n)!/(n!*(n+1)!)

//stirling second - number of ways to partition a set of n objects into k non-empty subsets 
// S[n+1][k] = k*S[n][k] + S[n][k-1]
// S[0][0] = 1
// S[n][0] = S[0][n] = 0 , n > 0
