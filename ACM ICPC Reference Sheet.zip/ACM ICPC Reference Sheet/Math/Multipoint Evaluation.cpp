// reference: https://judge.yosupo.jp/submission/117

const int MOD = 998244353;
using namespace std;
using uint = unsigned int;
using ll = long long;
using ull = unsigned long long;
constexpr ll TEN(int n) { return (n == 0) ? 1 : 10 * TEN(n - 1); }
template <class T> using V = vector<T>;
template <class T> using VV = V<V<T>>;

template <uint MD> struct ModInt {
	using M = ModInt;
	const static M G;
	uint v;
	ModInt(ll _v = 0) { set_v(_v % MD + MD); }
	M& set_v(uint _v) {
		v = (_v < MD) ? _v : _v - MD;
		return *this;
	}
	explicit operator bool() const { return v != 0; }
	M operator-() const { return M() - *this; }
	M operator+(const M& r) const { return M().set_v(v + r.v); }
	M operator-(const M& r) const { return M().set_v(v + MD - r.v); }
	M operator*(const M& r) const { return M().set_v(ull(v) * r.v % MD); }
	M operator/(const M& r) const { return *this * r.inv(); }
	M& operator+=(const M& r) { return *this = *this + r; }
	M& operator-=(const M& r) { return *this = *this - r; }
	M& operator*=(const M& r) { return *this = *this * r; }
	M& operator/=(const M& r) { return *this = *this / r; }
	bool operator==(const M& r) const { return v == r.v; }
	M pow(ll n) const {
		M x = *this, r = 1;
		while (n) {
			if (n & 1) r *= x;
			x *= x;
			n >>= 1;
		}
		return r;
	}
	M inv() const { return pow(MD - 2); }
	friend ostream& operator<<(ostream& os, const M& r) { return os << r.v; }
};

using Mint = ModInt<MOD>;
template <> const Mint Mint::G = Mint(3);

template <class Mint> void nft(bool type, V<Mint>& a) {
	int n = int(a.size()), s = 0;
	while ((1 << s) < n) s++;
	assert(1 << s == n);
	static V<Mint> ep, iep;
	while (int(ep.size()) <= s) {
		ep.push_back(Mint::G.pow(Mint(-1).v / (1 << ep.size())));
		iep.push_back(ep.back().inv());
	}
	V<Mint> b(n);
	for (int i = 1; i <= s; i++) {
		int w = 1 << (s - i);
		Mint base = type ? iep[i] : ep[i], now = 1;
		for (int y = 0; y < n / 2; y += w) {
			for (int x = 0; x < w; x++) {
				auto l = a[y << 1 | x];
				auto r = now * a[y << 1 | x | w];
				b[y | x] = l + r;
				b[y | x | n >> 1] = l - r;
			}
			now *= base;
		}
		swap(a, b);
	}
}

template <class Mint> V<Mint> multiply(const V<Mint>& a, const V<Mint>& b) {
	int n = int(a.size()), m = int(b.size());
	if (!n || !m) return {};
	if (min(n, m) < 16) {
		V<Mint> ans(n + m - 1);
		for (int i = 0; i < n; i++)
			for (int j = 0; j < m; j++) ans[i + j] += a[i] * b[j];
		return ans;
	}
	int lg = 0;
	while ((1 << lg) < n + m - 1) lg++;
	int z = 1 << lg;
	auto a2 = a, b2 = b;
	a2.resize(z);
	b2.resize(z);
	nft(false, a2);
	nft(false, b2);
	for (int i = 0; i < z; i++) a2[i] *= b2[i];
	nft(true, a2);
	a2.resize(n + m - 1);
	Mint iz = Mint(z).inv();
	for (int i = 0; i < n + m - 1; i++) a2[i] *= iz;
	return a2;
}

template <class D> struct Poly {
	V<D> v;
	Poly(const V<D>& _v = {}) : v(_v) { shrink(); }
	void shrink() {
		while (v.size() && !v.back()) v.pop_back();
	}
	int size() const { return int(v.size()); }
	D freq(int p) const { return (p < size()) ? v[p] : D(0); }
	Poly operator+(const Poly& r) const {
		auto n = max(size(), r.size());
		V<D> res(n);
		for (int i = 0; i < n; i++) res[i] = freq(i) + r.freq(i);
		return res;
	}
	Poly operator-(const Poly& r) const {
		int n = max(size(), r.size());
		V<D> res(n);
		for (int i = 0; i < n; i++) res[i] = freq(i) - r.freq(i);
		return res;
	}
	Poly operator*(const Poly& r) const { return {multiply(v, r.v)}; }
	Poly operator*(const D& r) const {
		int n = size();
		V<D> res(n);
		for (int i = 0; i < n; i++) res[i] = v[i] * r;
		return res;
	}
	Poly operator/(const D& r) const { return *this * r.inv(); }
	Poly operator/(const Poly& r) const {
		if (size() < r.size()) return {{}};
		int n = size() - r.size() + 1;
		return (rev().pre(n) * r.rev().inv(n)).pre(n).rev(n);
	}
	Poly operator%(const Poly& r) const { return *this - *this / r * r; }
	Poly operator<<(int s) const {
		V<D> res(size() + s);
		for (int i = 0; i < size(); i++) res[i + s] = v[i];
		return res;
	}
	Poly operator>>(int s) const {
		if (size() <= s) return Poly();
		V<D> res(size() - s);
		for (int i = 0; i < size() - s; i++) res[i] = v[i + s];
		return res;
	}
	Poly& operator+=(const Poly& r) { return *this = *this + r; }
	Poly& operator-=(const Poly& r) { return *this = *this - r; }
	Poly& operator*=(const Poly& r) { return *this = *this * r; }
	Poly& operator*=(const D& r) { return *this = *this * r; }
	Poly& operator/=(const Poly& r) { return *this = *this / r; }
	Poly& operator/=(const D& r) { return *this = *this / r; }
	Poly& operator%=(const Poly& r) { return *this = *this % r; }
	Poly& operator<<=(const size_t& n) { return *this = *this << n; }
	Poly& operator>>=(const size_t& n) { return *this = *this >> n; }

	Poly pre(int le) const {
		return {{v.begin(), v.begin() + min(size(), le)}};
	}
	Poly rev(int n = -1) const {
		V<D> res = v;
		if (n != -1) res.resize(n);
		reverse(res.begin(), res.end());
		return res;
	}
	Poly diff() const {
		V<D> res(max(0, size() - 1));
		for (int i = 1; i < size(); i++) res[i - 1] = freq(i) * i;
		return res;
	}
	Poly inte() const {
		V<D> res(size() + 1);
		for (int i = 0; i < size(); i++) res[i + 1] = freq(i) / (i + 1);
		return res;
	}
	// f * f.inv() = 1 + g(x)x^m
	Poly inv(int m) const {
		Poly res = Poly({D(1) / freq(0)});
		for (int i = 1; i < m; i *= 2) {
			res = (res * D(2) - res * res * pre(2 * i)).pre(2 * i);
		}
		return res.pre(m);
	}
	Poly exp(int n) const {
		assert(freq(0) == 0);
		Poly f({1}), g({1});
		for (int i = 1; i < n; i *= 2) {
			g = (g * 2 - f * g * g).pre(i);
			Poly q = diff().pre(i - 1);
			Poly w = (q + g * (f.diff() - f * q)).pre(2 * i - 1);
			f = (f + f * (*this - w.inte()).pre(2 * i)).pre(2 * i);
		}
		return f.pre(n);
	}
	Poly log(int n) const {
		assert(freq(0) == 1);
		auto f = pre(n);
		return (f.diff() * f.inv(n - 1)).pre(n - 1).inte();
	}
	Poly sqrt(int n) const {
		assert(freq(0) == 1);
		Poly f = pre(n + 1);
		Poly g({1});
		for (int i = 1; i < n; i *= 2) {
			g = (g + f.pre(2 * i) * g.inv(2 * i)) / 2;
		}
		return g.pre(n + 1);
	}
	Poly pow_mod(ll n, const Poly& mod) {
		Poly x = *this, r = {{1}};
		while (n) {
			if (n & 1) r = r * x % mod;
			x = x * x % mod;
			n >>= 1;
		}
		return r;
	}
	friend ostream& operator<<(ostream& os, const Poly& p) {
		if (p.size() == 0) return os << "0";
		for (auto i = 0; i < p.size(); i++) {
			if (p.v[i]) {
				os << p.v[i] << "x^" << i;
				if (i != p.size() - 1) os << "+";
			}
		}
		return os;
	}
};

template <class Mint> struct MultiEval {
	using NP = MultiEval*;
	NP l, r;
	V<Mint> que;
	int sz;
	Poly<Mint> mul;
	MultiEval(const V<Mint>& _que, int off, int _sz) : sz(_sz) {
		if (sz <= 100) {
			que = {_que.begin() + off, _que.begin() + off + sz};
			mul = {{1}};
			for (auto x : que) mul *= {{ -x, 1}};
			return;
		}
		l = new MultiEval(_que, off, sz / 2);
		r = new MultiEval(_que, off + sz / 2, sz - sz / 2);
		mul = l->mul * r->mul;
	}
	MultiEval(const V<Mint>& _que) : MultiEval(_que, 0, int(_que.size())) {}
	void query(const Poly<Mint>& _pol, V<Mint>& res) const {
		if (sz <= 100) {
			for (auto x : que) {
				Mint sm = 0, base = 1;
				for (int i = 0; i < _pol.size(); i++) {
					sm += base * _pol.freq(i);
					base *= x;
				}
				res.push_back(sm);
			}
			return;
		}
		auto pol = _pol % mul;
		l->query(pol, res);
		r->query(pol, res);
	}
	V<Mint> query(const Poly<Mint>& pol) const {
		V<Mint> res;
		query(pol, res);
		return res;
	}
};

// driver function (c -> polynomial, p -> points)
int main() {
	V<Mint> c(n), p(m);
	for (int i = 0; i < n; i++) cin >> c[i].v;
	for (int i = 0; i < m; i++) cin >> p[i].v;
	auto pol = Poly<Mint>(c);
	auto multi_eval = MultiEval<Mint>(p);
	auto answer = multi_eval.query(pol);
	return 0;
}