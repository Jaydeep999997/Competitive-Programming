const int N = 2e5+10 , LN =18;

//SEGTREE : point update and range max query 

vi g[N];
int par[N],dep[N],sz[N],heavy[N],head[N],pos[N],a[N];
int cur_pos = 0,n,q;

void dfs(int node,int p = -1) 
{
	if(p == -1) dep[node] = 0;
    else dep[node] = dep[p] + 1;
    
    par[node] = p;
    sz[node] = 1;
    
    for (int x : g[node]) 
        if (x != p) 
        {
            dfs(x,node);
            sz[node]+=sz[x];
        }
}

void dfs2(int v, int hed)
{
    pos[v] = cur_pos++;
    head[v] = hed;
    update(0,0,n-1,pos[v],a[v]);
    int mx = -1, bigChild = -1;
    
    for(auto u : g[v])
    {
       if(u != par[v] && sz[u] > mx)
             mx = sz[u], bigChild = u;
    }
    
    if(bigChild != -1) dfs2(bigChild,hed);
    
    for(auto u : g[v])
        if(u != par[v] && u != bigChild) dfs2(u,u);  
}
 
int paint(int a, int b) 
{
    int res = 0;
    
    for (; head[a] != head[b]; b = par[head[b]])
    {
        if(dep[head[a]] > dep[head[b]]) swap(a,b); 
        res = max(res , query(0,0,n-1,pos[head[b]],pos[b]));
    }
    
    if (dep[a] > dep[b]) swap(a, b);
    res = max(res,query(0,0,n-1,pos[a],pos[b]));
    
    return res;
}
 
signed main()
{
  //n,q and tree input 
  
  dfs(1); 
  dfs2(1,1);
  
  //paint gives answer ,can modify it for update as well 
  //pos[x] gives the position of node x in segment tree , so we can update / query there
}
