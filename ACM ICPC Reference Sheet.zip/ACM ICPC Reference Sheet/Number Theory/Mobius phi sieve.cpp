const int N = 2e5 + 10;
vector<int> lastprime(N,-1),phi(N),mobius(N);

void sieve_lastprime()
{
  lastprime[0] = lastprime [1] = 0;
    
  for(int i=2;i<N;i++)
  {
    if(lastprime[i] == -1)
        for(int j=i*i;j<N;j+=i) //make sure int is defined long long 
            lastprime[j] = i;  
  }
}

void sieve_phi()
{
    for(int i=0;i<N;i++) phi[i] = i;
    
    for(int i=2;i<N;i++)
      if(phi[i] == i)
          for(int j=i;j<N;j+=i) phi[j] -= (phi[j]/i);
}

void sieve_mobius()
{
  sieve_lastprime();  
    
  mobius[0] = 0;
  mobius[1] = 1;
    
  for(int i=2;i<N;i++)
  {
      if(lastprime[i] == -1) mobius[i] = -1;
      else if( (i/lastprime[i]) % lastprime[i] == 0) mobius[i] = 0;
      else mobius[i] = (mobius[lastprime[i]]*mobius[i/lastprime[i]]);
  }
}